ACQUAFY - Materiais de Marketing
================================

Este pacote reúne materiais para divulgação do programa Acquafy WaaS.

Conteúdo:
  - readme.txt ............ este arquivo
  - guia-de-uso-da-marca.txt  orientações de uso da marca

Pacote de demonstração do Portal do Investidor. Os arquivos de imagem
(logotipos, fotos, artes para redes sociais) são enviados pela equipe
Acquafy em atualizações do pacote.
